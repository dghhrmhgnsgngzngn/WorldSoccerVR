World Soccer VR v0.6 Outdoor Stadium. Replace the existing index.html at the root of your GitHub Pages repository. Experimental Quest WebXR prototype; controller feet, dribbling and kicking retained.
